ALTER TABLE goadmin_menu
ADD COLUMN `uuid` varchar(150) NOT NULL DEFAULT '',
ADD COLUMN `plugin_name` varchar(150) NOT NULL DEFAULT '';