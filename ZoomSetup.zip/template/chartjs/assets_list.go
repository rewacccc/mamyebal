package chartjs

var AssetsList = []string{
	"/chart.min.js",
}
