package mysql

import _ "github.com/go-sql-driver/mysql" // Import the mysql driver.
