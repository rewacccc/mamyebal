package mssql

import _ "github.com/denisenkom/go-mssqldb" // Import the mssql driver.
